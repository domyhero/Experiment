// =====================================================================================
// 
//       Filename:  Pretreatment.cpp
//
//    Description:  预处理器
//
//        Version:  1.0
//        Created:  2014年04月07日 16时24分12秒
//       Revision:  none
//       Compiler:  g++
//
//         Author:  Hurley (LiuHuan), liuhuan1992@gmail.com
//        Company:  Class 1107 of Computer Science and Technology
// 
// =====================================================================================

#include "Pretreatment.h"
