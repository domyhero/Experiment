int main(int argc, char *argv[])
{
	int a = 1, b = 2;
	
	if (a > b) {
		return 1;
	}
	
	return 0;
}
